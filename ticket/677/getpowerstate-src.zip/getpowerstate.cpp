// getpowerstate.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int _tmain( int argc, _TCHAR* argv[] )
{
	int i = 1;
	DWORD dwPermissions = 0;
	if( argc > i )
		if( _tcsicmp( argv[ i ], _T( "-0" ) ) == 0 )
		{
			dwPermissions = 0;
			i++;
		}
		else if( _tcsicmp( argv[ i ], _T( "-r" ) ) == 0 )
		{
			dwPermissions = GENERIC_READ;
			i++;
		}
		else    if( _tcsicmp( argv[ i ], _T( "-rw" ) ) == 0 )
		{
			dwPermissions = GENERIC_READ | GENERIC_WRITE;
			i++;
		}
		if( argc <= i )
		{
			_tprintf( _T( "Usage: [-0|-r|-rw] \\\\.\\PhysicalDrive<N>\n" ) );
			return 1;
		}

		HANDLE h = CreateFile( argv[ i ], dwPermissions, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, 0 );
		if( h != INVALID_HANDLE_VALUE )
		{
			BOOL blPowerState;
			if( GetDevicePowerState( h, &blPowerState ) )
			{
				_tprintf( _T( "Power state for %s is %d\n" ), argv[ i ], blPowerState );
			}
			else
			{
				_tprintf( _T( "GetDevicePowerState failed. Error = %0X\n" ), GetLastError() );
			}
			CloseHandle( h );
		}
		else
		{
			_tprintf( _T( "CreateFile failed. Error = %0X\n" ), GetLastError() );
		}
		return 0;
}

