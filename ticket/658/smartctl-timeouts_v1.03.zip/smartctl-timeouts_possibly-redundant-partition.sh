#! /bin/sh
# smartctl-timeouts_possibly-redundant-partition.sh

# This script sets the timeouts for "mixed drives" that contain redundant
# and non-redundant partitions.

# A single, possibly-redundant partition is enough to set the entire drive's
# timeouts to possibly-redundant settings (with a determined ERC timeout slightly
# below the default or configured controller timout, if possible).
#
# This avoids to risk unknown disk recovery times and needing a very long
# controller timeouts. Where configuring such a ERC timout is possible,
# this means the disk recovery may be terminated quicker than the drive
# would without the timout set, but it ensures that there will be no resets
# leading to data loss and redundancy loss.

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
$SCRIPT_DIR/smartctl-timeouts_possibly-redundant-disk.sh $1
