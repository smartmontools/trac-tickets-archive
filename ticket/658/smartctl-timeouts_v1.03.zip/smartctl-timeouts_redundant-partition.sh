#!/bin/sh
# smartctl-timeouts_redundant-partition.sh

# Redundant timouts are NEVER to be triggerd by udev rules!
# Because only the redundancy providing kernel module knows the actual run-time
# redundancy status, can adjust it and call this script dynamically.
# Udev rules can only determine "possibly redundant" devices.

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/smartctl-timeouts_defaults

HDD_DEV="$1"

REDUNDANT_DISK="checking"

# TODO
#for dev in `cd /sys/block/${HDD_DEV} ; ls -d ${HDD_DEV}*` ; do
#  if equvalent to udev's ENV{REDUNDANT_DEV}=="false|"; then
#    $REDUNDANT_DISK="false"
#  fi
#done
#if [ $REDUNDANT_DISK="checking" ] ; then
#  REDUNDANT_DISK="true"
#fi

if [ $REDUNDANT_DISK = "true" ] \
# TODO:  && all partitions have been detected by udev already
then
  $SCRIPT_DIR/smartctl-timeouts_redundant-disk.sh $1
else
  $SCRIPT_DIR/smartctl-timeouts_possibly-redundant-disk.sh $1
fi
