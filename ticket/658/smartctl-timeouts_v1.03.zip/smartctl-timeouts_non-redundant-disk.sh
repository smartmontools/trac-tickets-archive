#!/bin/sh
# smartctl-timeouts_non-redundant-disk.sh

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/smartctl-timeouts_defaults

HDD_DEV="$1"

echo "Adjusting $HDD_DEV timeouts:"

if [ ${NONREDUNDANT_UNSURE_RESET_ALL_DISKS:-false} = "true" ] ; then
  # * disable any ERC timeout
  #   - Allows the drive to do ERC without imposing a timeout.
  ${TIMING_CMD},0,0 /dev/${HDD_DEV} > /dev/null

  # * Set the controller timeout to be considerably loooooong.
  #   - To allow the drive to give up its ERC attempts by itself.
  #   - Let the drive return a proper read error, so that the redundancy
  #     provider (md, lvm, btrfs, ...) can re-write the bad block.
  #   - Disk read errors thus result in long i/o blocking periods with
  #     no error messages that may not be watched by or reported to the user,
  #   - but waiting this long should prevent unecessary controller resets of the
  #     entire drive and the corresponding loss of redundancy/data.
  echo "NONREDUNDANT_UNSURE_RESET_ALL_DISKS is true, setting NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS (${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS}s)"
  echo ${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS} >/sys/block/${HDD_DEV}/device/timeout


else

  if ! ${TIMING_CMD} /dev/${HDD_DEV} | grep -q Disabled \
    && ! ${TIMING_CMD} /dev/${HDD_DEV} | grep -q seconds
  then
    # ERC timeout is not supported (not disabled and not set)
    # * Set the controller timeout to be considerably loooooong.
    echo "Drive without ERC timeout support, setting NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS (${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS}s)"
    echo ${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS} >/sys/block/${HDD_DEV}/device/timeout

  else

    if ${TIMING_CMD} /dev/${HDD_DEV} | grep -q seconds \
      || [ ${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-undefined} != "undefined" ]
    then

      # reset controller timeout, if a configured value was previously set
      if [ `cat /sys/block/${HDD_DEV}/device/timeout` = ${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS:--1} ] \
        || [ `cat /sys/block/${HDD_DEV}/device/timeout` = ${POSSIBLY_REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:--1} ] \
        || [ `cat /sys/block/${HDD_DEV}/device/timeout` = ${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:--1} ]
      then
        echo "resetting controller from another configured value (`cat /sys/block/${HDD_DEV}/device/timeout`s) to ${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-60}s"
        echo ${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-60} >/sys/block/${HDD_DEV}/device/timeout
      else
        # set non-redundant timeout anyway, if configured
        if [ ${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-undefined} != "undefined" ] ; then
          echo "setting configured NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS (${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS}s)"
          echo ${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS} >/sys/block/${HDD_DEV}/device/timeout
        fi
      fi

      # An ERC timeout is set or configured:
      # * change ERC timout to controller timeout -5 seconds
      #   - Longer than the usual 7s default of dedicated raid drives, to allow as much
      #     ERC time as possible.
      ERC_TENTHS=$(expr `cat /sys/block/${HDD_DEV}/device/timeout` \* 10 - 50)

      # prevent exceeding max. scterc value
      if [ $ERC_TENTHS -gt 999 ] ; then
        ERC_TENTHS="999"
      fi

      echo "maximizing ERC timeout to controller timeout -5 seconds (`expr $ERC_TENTHS / 10`s)"
      ${TIMING_CMD},$ERC_TENTHS,$ERC_TENTHS /dev/${HDD_DEV} > /dev/null

    else # ERC timeout disabled
      echo "found ERC timeout disabled, setting NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS (${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS}s)"
      echo ${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS} >/sys/block/${HDD_DEV}/device/timeout
    fi
  fi
fi
