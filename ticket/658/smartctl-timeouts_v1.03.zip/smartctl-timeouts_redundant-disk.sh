#!/bin/sh
# smartctl-timeouts_redundant-disk.sh

# Redundant timouts are NEVER to be triggerd by udev rules!
# Because only the redundancy providing kernel module knows the actual run-time
# redundancy status, can adjust it and call this script dynamically.
# Udev rules can only determine "possibly redundant" devices.

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/smartctl-timeouts_defaults

HDD_DEV="$1"

echo "Adjusting $HDD_DEV timeouts:"

if ! ${TIMING_CMD} /dev/${HDD_DEV} | grep -q Disabled \
  && ! ${TIMING_CMD} /dev/${HDD_DEV} | grep -q seconds
then
    # ERC timeout is not supported (not disabled and not set):
    # * Set the controller timeout to be considerably loooooong.
    #   - To allow the drive to give up its ERC attempts by itself.
    #   - Let the drive return a proper read error, so that the redundancy
    #     provider (md, lvm, btrfs, ...) can re-write the bad block.
    #   - Disk read errors thus result in long i/o blocking periods with
    #     no error messages that may not be watched by or reported to the user,
    #   - but waiting this long should prevent unecessary controller resets of the
    #     entire drive and the corresponding loss of redundancy/data.
    echo "Drive without ERC timeout support, setting NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS (${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS}s)"
    echo ${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS} >/sys/block/${HDD_DEV}/device/timeout
else
  SWITCH_FROM_OTHER_CONFIGURED_SMARTCTL_TIMEOUT="false"

  # reset controller timeout, if a configured value was previously set
  if [ `cat /sys/block/${HDD_DEV}/device/timeout` = ${NONREDUNDANT_UNSURE_CONTROLLER_RESET_SECONDS:--1} ] \
    || [ `cat /sys/block/${HDD_DEV}/device/timeout` = ${NONREDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:--1} ] \
    || [ `cat /sys/block/${HDD_DEV}/device/timeout` = ${POSSIBLY_REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:--1} ]
  then
    SWITCH_FROM_OTHER_CONFIGURED_SMARTCTL_TIMEOUT="true"
    echo "resetting controller from another configured value (`cat /sys/block/${HDD_DEV}/device/timeout`s) to ${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-30}s"
    echo ${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-30} >/sys/block/${HDD_DEV}/device/timeout
  else
    # set possibly-redundant timeout anyway, if configured
    if [ ${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-undefined} != "undefined" ] ; then
      echo "setting controller timeout to REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS (${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS}s)"
      echo ${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS} >/sys/block/${HDD_DEV}/device/timeout
    else
      if [ `cat /sys/block/${HDD_DEV}/device/timeout` -gt 30 ] ; then
        echo "reducing controller timout to 30 seconds"
        echo 30 >/sys/block/${HDD_DEV}/device/timeout
      fi
    fi
  fi

  if ${TIMING_CMD} /dev/${HDD_DEV} | grep -q Disabled \
    || [ $SWITCH_FROM_OTHER_CONFIGURED_SMARTCTL_TIMEOUT = "true" ] \
    || [ ${REDUNDANT_DISK_CONTROLLER_TIMEOUT_SECONDS:-undefined} != "undefined" ] \
# TODO:  || [ $(expr `cat /sys/block/${HDD_DEV}/device/timeout` \* 10 - 50) = read of current ERC timeout value ]
  then
    # ERC timeout is disabled, is configured, or has been "maximized" to the controller timeout -5 seconds:
    # * set it to 7 seconds
    #   - The usual quick 7s default of dedicated raid drives.
    #   - Allows redundancy provider to quickly read data from another disk and re-write the bad block
    #     before the controller resets the entire drive and the raid looses redundancy/data completely.
    echo "setting ERC timeout to 7 seconds"
    ${TIMING_CMD},70,70 /dev/${HDD_DEV} > /dev/null
  fi
fi
