#!/bin/sh
# smartctl-timeouts_non-redundant-partition.sh

# Because there may also be redundant partitions on this disk we must not
# unconditionally alter the timeouts.

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/smartctl-timeouts_defaults

HDD_DEV="$1"

REDUNDANT_DISK="checking"

# TODO
#for dev in `cd /sys/block/${HDD_DEV} ; ls -d ${HDD_DEV}*` ; do
#  if equvalent to udev's ENV{REDUNDANT_DEV}=="yes|possibly"; then
#    $REDUNDANT_DISK="possibly"
#  fi
#done
#if [ $REDUNDANT_DISK="checking" ] ; then
#  REDUNDANT_DISK="false"
#fi

if [ $REDUNDANT_DISK = "false" ] \
# TODO  && all partitions have been detected by udev already
then
  $SCRIPT_DIR/smartctl-timeouts_non-redundant-disk.sh $1
else
  $SCRIPT_DIR/smartctl-timeouts_possibly-redundant-disk.sh $1
fi
